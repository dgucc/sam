let favorite_synth_list = [
    {class_name:"nom_cours", synth_name:"nom_synthese", autor_name:"nom_auteur"},
    {class_name:"nom_cours", synth_name:"nom_synthese", autor_name:"nom_auteur"},
    {class_name:"nom_cours", synth_name:"nom_synthese", autor_name:"nom_auteur"},
    {class_name:"nom_cours", synth_name:"nom_synthese", autor_name:"nom_auteur"},
    {class_name:"nom_cours", synth_name:"nom_synthese", autor_name:"nom_auteur"},
    {class_name:"nom_cours", synth_name:"nom_synthese", autor_name:"nom_auteur"},
    {class_name:"nom_cours", synth_name:"nom_synthese", autor_name:"nom_auteur"},
    {class_name:"nom_cours", synth_name:"nom_synthese", autor_name:"nom_auteur"},
    {class_name:"nom_cours", synth_name:"nom_synthese", autor_name:"nom_auteur"},
    {class_name:"nom_cours", synth_name:"nom_synthese", autor_name:"nom_auteur"},
    {class_name:"nom_cours", synth_name:"nom_synthese", autor_name:"nom_auteur"}
]

let favorite_class_list = [
    {class_name:"nom_cours"},
    {class_name:"nom_cours"},
]

//Pour rajouter les éléments de la liste des syntheses favorites
let favoriteBlock = document.getElementById("synth_favoris");
for (let favorite of favorite_synth_list){
    let a = document.createElement("a");
    a.href = "https://osu.ppy.sh/users/27056232";
    let div = document.createElement("div");
    div.classList.add("colonne_element");
    div.classList.add("smooth_policy");
    div.textContent = favorite.class_name + " | " + favorite.synth_name + " | " + favorite.autor_name;

    a.appendChild(div);
    favoriteBlock.appendChild(a);
}

//Pour rajouter les éléments de la liste des cours favoris
let favorite_class_block = document.getElementById("cours_favoris");
for (let favorite of favorite_class_list){
    let a = document.createElement("a");
    a.href = "https://osu.ppy.sh/users/27056232";
    let div = document.createElement("div");
    div.classList.add("colonne_element");
    div.classList.add("smooth_policy");
    div.textContent = favorite.class_name;

    a.appendChild(div);
    favorite_class_block.appendChild(a);
}