let my_synth_list = [
    {class_name:"nom_classe", synth_name:"nom_synthese"},
    {class_name:"nom_classe", synth_name:"nom_synthese"},
    {class_name:"nom_classe", synth_name:"nom_synthese"},
    {class_name:"nom_classe", synth_name:"nom_synthese"},
    {class_name:"nom_classe", synth_name:"nom_synthese"}
]

//Pour rajouter les éléments de la liste des syntheses personnelles
let synth_block = document.getElementById("liste_mes_syntheses");
for (let synth of my_synth_list){
    let a = document.createElement("a");
    a.href = "https://osu.ppy.sh/users/27056232";
    let div = document.createElement("div");
    div.classList.add("colonne_element");
    div.classList.add("smooth_policy");
    div.textContent = synth.class_name + " | " + synth.synth_name;

    a.appendChild(div);
    synth_block.appendChild(a);
}