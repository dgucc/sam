// let faculte_list = [
    // {name:"Faculté de droit", img:"assets/hp_fac_droit.ICO"},
    // {name:"Faculté Économie Management Communcation sciencesPo", img:"assets/hp_ecogestion.ICO"},
    // {name:"Faculté d'informatique", img:"assets/hp_informatique.ico"},
    // {name:"Faculté de médecine", img:"assets/hp_medecine.ico"},
    // {name:"Faculté de philosophie et lettres", img:"assets/hp_philo_lettres.ico"},
    // {name:"Faculté des sciences", img:"assets/hp_sciences.ico"},
    // {name:"Faculté des sciences de l'éducation et de la formation", img:"assets/hp_education_formation.ico"}
// ]

//Corps principale du code
load_data();

// L'URL du service REST à interroger
function load_data(){
    fetch('http://localhost:8080/facultes')
        .then(response => response.json()) // Convertir la réponse en JSON
        .then(data => {
            // Afficher les universités
            console.log(data);
            let faculte_block = document.getElementById("liste_faculte");
            print_faculte(data);
            // for (let faculte_el of data){
            //     let a = document.createElement("a");
            //     a.href = "https://osu.ppy.sh/users/27056232";

            //     let faculte = document.createElement("div");
            //     faculte.classList = "faculte";

            //     let image_container = document.createElement("div");
            //     image_container.classList = "image";

            //     let image = document.createElement("img");
            //     image.src = faculte_el.img;

            //     let name = document.createElement("div");
            //     name.classList.add("nom_faculte");
            //     name.classList.add("smooth_policy");
            //     name.textContent = faculte_el.name;

            //     image_container.appendChild(image);
            //     faculte.appendChild(image_container);
            //     faculte.appendChild(name);
            //     a.appendChild(faculte);
            //     faculte_block.appendChild(a);
            // }
        })
        .catch(error => {
            console.error('Erreur :', error);
    });
}

//Pour rajouter les éléments de la liste des facultés
function print_faculte(data){
    console.log("test" + JSON.stringify(data));
    let faculte_block = document.getElementById("liste_faculte");
    // const facultes = JSON.parse(json_string);
    for (let faculte_el of data){
        let a = document.createElement("a");
        a.href = "https://osu.ppy.sh/users/27056232";

        let faculte = document.createElement("div");
        faculte.classList = "faculte";

        let image_container = document.createElement("div");
        image_container.classList = "image";

        let image = document.createElement("img");
        image.src = faculte_el.img;

        let name = document.createElement("div");
        name.classList.add("nom_faculte");
        name.classList.add("smooth_policy");
        name.textContent = faculte_el.name;

        image_container.appendChild(image);
        faculte.appendChild(image_container);
        faculte.appendChild(name);
        a.appendChild(faculte);
        faculte_block.appendChild(a);
    }
}