package Projet_groupe02.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;

import Projet_groupe02.demo.service.UsynthService;

@RestController
@CrossOrigin(origins = "*") //Bloque les CORPS en acceptant tout les noms de domaines (obligatoire pour FireFox)
public class UsynthController {
  
    @Autowired
    private UsynthService service;

    @GetMapping("/facultes")
    public ResponseEntity<?> getListFacultes(){
        return new ResponseEntity<>(service.getListFacultes(), HttpStatus.OK);
    }
}
