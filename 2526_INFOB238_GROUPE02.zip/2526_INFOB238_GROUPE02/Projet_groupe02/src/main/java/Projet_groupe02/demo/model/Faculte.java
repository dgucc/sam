package Projet_groupe02.demo.model;

public class Faculte {
    private String name;
    private String img;
    
    public Faculte() {
    }
    public Faculte(String name, String img) {
        this.name = name;
        this.img = img;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getImg() {
        return img;
    }
    public void setImg(String img) {
        this.img = img;
    }
    
}
