package Projet_groupe02.demo.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;
import Projet_groupe02.demo.model.Faculte;

@Service
public class UsynthService {

    // public List<String> getListFacultes(){
    //     return Arrays.asList(
    //         new String("Faculté de droit"),
    //         new String("Faculté Économie Management Communcation sciencesPo"),
    //         new String("Faculté d'informatique"),
    //         new String("Faculté de médecine")
    //     );
    // }
    public List<Faculte> getListFacultes(){
        return Arrays.asList(
            new Faculte("Faculté de droit", "assets/hp_fac_droit.ICO"),
            new Faculte("Faculté Économie Management Communcation sciencesPo", "assets/hp_ecogestion.ICO"),
            new Faculte("Faculté d'informatique", "assets/hp_informatique.ico"),
            new Faculte("Faculté de médecine", "assets/hp_medecine.ico"),
            new Faculte("Faculté de philosophie et lettres", "assets/hp_informatique.ico"),
            new Faculte("Faculté des sciences", "assets/hp_sciences.ico"),
            new Faculte("Faculté des sciences de l'éducation et de la formation", "assets/hp_education_formation.ico")
        );
    }
}